
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int course_id;
		String course_name;
		course_id=1001;
		course_name="Introduction to Java";
		
		
		System.out.println("Hello World");
		System.out.println("Course Name : " + course_name);
		System.out.println("Course ID : " + course_id);
	}

}
