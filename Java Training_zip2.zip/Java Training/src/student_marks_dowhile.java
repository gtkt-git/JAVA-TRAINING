import java.util.Scanner;
public class student_marks_dowhile {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		String student_name,dob,dept;
		char choice;
		int i,no_of_students,reg_id, mark1, mark2, mark3;
//		float basic_sal, hra,da,tax,pr;
		
//		i=0;
//		System.out.println("pls enter number of students: ");
//		no_of_students=s.nextInt();

//		while (i<no_of_students)
		do
		{
		
		System.out.println("pls enter your name: ");
		student_name=s.next();

		System.out.println("pls enter your date of birth: ");
		dob=s.next();
		
		System.out.println("pls enter your department: ");
		dept=s.next();
		
		System.out.println("pls enter Registration No: ");
		reg_id=s.nextInt();

		System.out.println("pls enter Mark 1: ");
		mark1=s.nextInt();
		
		System.out.println("pls enter Mark 2: ");
		mark2=s.nextInt();
	
		System.out.println("pls enter Mark 3: ");
		mark3=s.nextInt();
	
		int total_mark=mark1 + mark2 + mark3;
		float avg_mark=total_mark / 3;
		String result,grade;
		
		
		if (avg_mark>=80) 
			{grade="A";}
		else if (avg_mark>60 && avg_mark<80)
			{	grade="B";}
		else if (avg_mark>50 && avg_mark<60)
			{	grade="C";}
		else 
			{grade="D";}
		
		if (mark1>=50  && mark2 >= 50 && mark3 >= 50) 
			{result="Pass";}
		else 
			{result="Fail";}
		
//		float total_earnings=basic_sal+hra;
//		float total_ded=tax;
		
//		float gross_sal=total_earnings-total_ded;
		
		
		System.out.println("Student Marklist");
		System.out.println("=================");
		System.out.println("STUDENT NAME: " + student_name + "\t D.O.B: " + dob);
		System.out.println("Registration No: " + reg_id);
		System.out.println("============");
//		System.out.println("Mark 1: " + mark1 + "\t Dept: " + dept);
		System.out.println("Mark 1: " + mark1 + "\t \t Dept: " + dept);
		System.out.println("Mark 2: " + mark2);
		System.out.println("Mark 3: " + mark3);
//		System.out.println("GROSS SALARY: " + gross_sal);
		System.out.println("============");
		System.out.println("Total mark: " + total_mark + "\t \t Avg Mark: " + avg_mark);
		System.out.println("Result: " + result + "\t \t Grade: " + grade);
//		System.out.println("Mark 3: " + hra + "EMP TAX: " + tax);
//		System.out.println("GROSS SALARY: " + gross_sal);
//		i++;
		System.out.println("do u want to continue? (Y/N) ");
		choice=s.next().charAt(0);
		} while (choice!='N');
	}
	
}
