package Strings_demo;

public class string_creation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1="hello string";
		String s2= new String ("goodbye string");
		System.out.println("literal string: "+s1);
		System.out.println("keyword string: "+s2);
		s1.concat("concat");
		System.out.println("concat string: "+s1);
		s1=s1.concat(" concat");
		System.out.println("concat string: "+s1);
		
		
	}

}
