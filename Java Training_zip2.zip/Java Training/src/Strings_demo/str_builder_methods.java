package Strings_demo;

public class str_builder_methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuilder sb=new StringBuilder("Hello");
		StringBuilder sb2=new StringBuilder("HTML");
		sb.append(" World");
		System.out.println("using string buffer: " +sb);
		System.out.println(sb.insert(3,"servlet"));
		System.out.println(sb);
		
		System.out.println(sb.replace(3,5,"JSP"));
		System.out.println(sb);

		System.out.println(sb.delete(3,5));	// deletes up to index 4
		System.out.println(sb);
		
		System.out.println(sb.reverse());
		System.out.println(sb);
		
		System.out.println(sb.capacity());
		System.out.println(sb2.capacity());
		
	}

}
