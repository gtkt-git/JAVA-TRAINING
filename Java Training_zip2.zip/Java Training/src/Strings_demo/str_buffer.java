package Strings_demo;


public class str_buffer {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer sb=new StringBuffer("Hello");
		sb.append(" World");
		System.out.println("using string buffer: " +sb);
		
		String str=new String("Hello");
		str.concat(" World");
		System.out.println("using string: " +str);
		
		String str2="String";
		str2.concat(" literal");
		System.out.println("using string literal: " +str2);
		
		StringBuilder sb2=new StringBuilder("Hello");
		sb2.append(" world");
		System.out.println("using string builder: " +sb2);
		
		
		
	}

}
