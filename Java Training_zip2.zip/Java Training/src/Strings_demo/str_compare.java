package Strings_demo;

public class str_compare {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1="Apple";
		String s2="Apple";
		String s3 = new String("apple");
		String s4 ="Kiwi";
		
		System.out.println(s1.equals(s2));	// compare values
		System.out.println(s1.equals(s3));
		System.out.println(s1.equals(s4));
		System.out.println(s1==(s2));	// compare address
		System.out.println(s1.compareTo(s2)); // compare values
		System.out.println(s1.compareTo(s3)); // compare values
		
	}

}
