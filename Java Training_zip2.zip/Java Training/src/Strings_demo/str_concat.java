package Strings_demo;

public class str_concat {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=110;
		String b="220";
		int c=200;
		String d="java training course in feb";
		String e="           java training course in feb";

		System.out.println(a+b);	// 110220
		System.out.println(a+c);	// 310
		System.out.println(b+c);	// 220200
		System.out.println(b.concat("500"));	// 220200 note b must be a string type
//		System.out.println(a.concat("500"));	// 220200 error 
		System.out.println(d.substring(10));	// from index 10 to the end of string
		System.out.println(d.substring(5,10));	// excludes end-index 10;from index 5 to 9
		System.out.println(d.toUpperCase());	// excludes end-index 10;from index 5 to 9
		System.out.println(d.toLowerCase());	// excludes end-index 10;from index 5 to 9
		System.out.println(d);	
		System.out.println(e);
		System.out.println(e.trim());
		System.out.println(e.trim()+ e.startsWith("Java"));
		System.out.println(e.trim()+ d.startsWith("Java"));
		System.out.println(e.trim()+ e.endsWith("feb"));
		System.out.println(e.trim()+ e.endsWith("Feb"));
		System.out.println(d.charAt(0));
		System.out.println(d.charAt(10));
		System.out.println(d.length());
		
		
		
	}

}
