import java.util.Scanner;
public class course_code {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		int course_code;
		String dept;
		
//		basic_sal=2800;
		
		System.out.println("pls enter Course Code: ");
		course_code=s.nextInt();

		switch (course_code)
		{
		case 101: 
			dept="CSE";
			System.out.println("Dept is : " + dept);
			break;
		case 102:
			dept="EEE";
			System.out.println("Dept is : " + dept);
			break;
		case 103:
			dept="MECH";
			System.out.println("Dept is : " + dept);
			break;
		case 104:
			dept="CIVIL";
			System.out.println("Dept is : " + dept);
			break;	
		default: 
			System.out.println("INVALID COURSE CODE");
		}
//		System.out.println("Dept is : " + dept);
		
		}

}
