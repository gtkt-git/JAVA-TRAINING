
public class if_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int acc_bal, withdrawal;
		acc_bal=10000;
		withdrawal=	15000;
		
		if (acc_bal>withdrawal) 
			{System.out.println("Successful");
			acc_bal=acc_bal - withdrawal;
			System.out.println("remaining bal :" + acc_bal);
			}
		else 
			{System.out.println("insufficient balance");
		
		}
	}

}
