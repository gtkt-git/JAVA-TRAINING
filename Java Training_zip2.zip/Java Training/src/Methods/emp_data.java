package Methods;

import java.util.Scanner;

public class emp_data {
	int emp_id,no_of_row, no_of_col;
	Scanner s = new Scanner(System.in);
	String emp_name;
	float basic_sal,hra,tax;
	float total_earnings,total_ded,gross_sal;

	void getData()
	{
		System.out.println("pls enter emp name: ");
		emp_name=s.next();
		
		System.out.println("pls enter emp ID: ");
		emp_id=s.nextInt();

		System.out.println("pls enter basic salary: ");
		basic_sal=s.nextFloat();
		
	}
	
	void calculate()
	{
	if (basic_sal>1000 && basic_sal<2000) 
		{hra=basic_sal*10/100;
		 tax=basic_sal*5/100;}
	else if (basic_sal>2000 && basic_sal<3000)
		{hra=basic_sal*20/100;
		 tax=basic_sal*10/100;}
	else if (basic_sal>3000 && basic_sal<4000)
		{hra=basic_sal*30/100;
		 tax=basic_sal*15/100;}

	else 
		{hra=basic_sal*50/100;
		 tax=basic_sal*20/100;}
	
	total_earnings=basic_sal+hra;
	total_ded=tax;
	
	gross_sal=total_earnings-total_ded;
	}
	
	void report()
	{
	System.out.println("JAN PAYSLIP");
	System.out.println("============");
	System.out.println("EMP NAME: " + emp_name + "       EMP ID: " + emp_id);
	System.out.println("BASIC SALARY: " + basic_sal);
	System.out.println("============");
	System.out.println("EMP HRA: " + hra + "      EMP TAX: " + tax);
	System.out.println("TOTAL SALARY: " + total_earnings);
//	System.out.println("EMP HRA: " + hra + "EMP TAX: " + tax);
	System.out.println("GROSS SALARY: " + gross_sal);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		emp_data obj = new emp_data();
		for (int i=0;i<3;i++)
		{	
		obj.getData();obj.calculate();obj.report();
		}
	}

}
