package Methods;

import java.util.Scanner;

class demo
{

	int add(int no1, int no2)
	{
		System.out.println("ADDITION:");
		System.out.println("---------");
//		System.out.println("pls enter num1: ");
//		num1=s.nextInt();
		
//		System.out.println("pls enter num2: ");
//		num2=s.nextInt();
		return (no1+no2);
	
	}
	
	int sub(int no1, int no2)
	{
		System.out.println("SUBTRACTION:");
		System.out.println("-----------");
//		System.out.println("pls enter num1: ");
//		num1=s.nextInt();
		
//		System.out.println("pls enter num2: ");
//		num2=s.nextInt();
		return (no1-no2);
	
	}
	
	float mul(int no1,int no2)
	{
		System.out.println("MULTIPLICATION:");
		System.out.println("--------------");
//		System.out.println("pls enter num1: ");
//		num1=s.nextInt();
		
//		System.out.println("pls enter num2: ");
//		num2=s.nextInt();
		return (no1*no2);
		}
	
	float div(int no1,int no2)
	{
		System.out.println("DIVISION:");
		System.out.println("--------");
//		System.out.println("pls enter num1: ");
//		num1=s.nextInt();
		
//		System.out.println("pls enter num2: ");
//		num2=s.nextInt();
		return (no1/no2);
}
}
	
public class arithmetic_params {
	int num1,num2;

	String emp_name;
	float n1,n2,result;
	float total_earnings,total_ded,gross_sal;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2;
		Scanner s = new Scanner(System.in);
		demo obj = new demo();
		
		System.out.println("pls enter num1: ");
		num1=s.nextInt();
		
		System.out.println("pls enter num2: ");
		num2=s.nextInt();
		int sum = obj.add(num1,num2);
		System.out.println("Sum is: " + sum);
		
		int subtract = obj.sub(num1,num2);
		System.out.println("difference is: " + subtract);
		float mul = obj.mul(num1,num2);
		System.out.println("Multiplication is: " + mul);
		float div = obj.div(num1,num2);
		System.out.println("division is: " + div);
		
//		obj.getData();obj.calculate();obj.report();
		}
	}


