package Methods;

import java.util.Scanner;

public class arithmetic {
	int num1,num2;
	Scanner s = new Scanner(System.in);
	String emp_name;
	float n1,n2,result;
	float total_earnings,total_ded,gross_sal;

	int add()
	{
		System.out.println("ADDITION:");
		System.out.println("---------");
		System.out.println("pls enter num1: ");
		num1=s.nextInt();
		
		System.out.println("pls enter num2: ");
		num2=s.nextInt();
		return (num1+num2);
	
	}
	
	int sub()
	{
		System.out.println("SUBTRACTION:");
		System.out.println("-----------");
		System.out.println("pls enter num1: ");
		num1=s.nextInt();
		
		System.out.println("pls enter num2: ");
		num2=s.nextInt();
		return (num1-num2);
	
	}
	
	float mul()
	{
		System.out.println("MULTIPLICATION:");
		System.out.println("--------------");
		System.out.println("pls enter num1: ");
		num1=s.nextInt();
		
		System.out.println("pls enter num2: ");
		num2=s.nextInt();
		return (num1*num2);
		}
	
	float div()
	{
		System.out.println("DIVISION:");
		System.out.println("--------");
		System.out.println("pls enter num1: ");
		num1=s.nextInt();
		
		System.out.println("pls enter num2: ");
		num2=s.nextInt();
		return (num1/num2);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		arithmetic obj = new arithmetic();
		arithmetic objb = new arithmetic();
		int sum = obj.add();
		System.out.println("Sum is: " + sum);
		int subtract = objb.sub();
		System.out.println("difference is: " + subtract);
		float mul = obj.mul();
		System.out.println("Multiplication is: " + mul);
		float div = obj.div();
		System.out.println("division is: " + div);
		
//		obj.getData();obj.calculate();obj.report();
		}
	}


