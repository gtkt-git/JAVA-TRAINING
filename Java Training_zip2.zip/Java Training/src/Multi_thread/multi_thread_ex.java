package Multi_thread;
import java.util.Scanner;

class task1 extends Thread
{
	public void run()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("enter the value n: ");
		int n = s.nextInt();
		
		for (int i=0;i<n;i++)
		{	
				System.out.println("thread 1: " + i*i*i);
		}
			
		
	}
}

class task2 extends Thread
{
	public void run()
	{
		Scanner s = new Scanner(System.in);
		System.out.println("enter the value n: ");
		int n = s.nextInt();
		
//		for (int i=0;i<n;i++)
//		{	
//				System.out.println("thread 2: " + i*i*i);
//		}
			
		for (int i=0;i<n;i++)
		{	if (i%2==0)
			{	System.out.println("thread 2: " + i);}
		}
	}
}

public class multi_thread_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		task1 t1 = new task1();
		task2 t2 = new task2();
		
		t1.start();
		t2.start();
				
	}

}
