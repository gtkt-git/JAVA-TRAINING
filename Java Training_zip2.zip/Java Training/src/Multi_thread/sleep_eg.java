package Multi_thread;

import java.util.Scanner;

public class sleep_eg extends Thread{

	public void run()
	{
//		Scanner s = new Scanner(System.in);
//		System.out.println("enter the value n: ");
//		int n = s.nextInt();
		
		for (int i=0;i<5;i++)
		{	
			try 
			{
				Thread.sleep(2000);
				
			}catch (InterruptedException e)
			
			{
			System.out.println(e);
			}
			System.out.println(i);
			
			System.out.println(Thread.currentThread().getName());
		}
		
	/*		if (Thread.currentThread.isDaemon
	 * 
	 * 	
	 */
		
			
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		sleep_eg t1 = new sleep_eg();
		sleep_eg t2 = new sleep_eg();
		
		t1.setPriority(8);
		t2.setPriority(7);
		t1.start();
		try 
		{	t1.join();} catch (Exception e)
			{System.out.println(e);
			}
		
		
		t2.start();
		try 
		{	t2.join();} catch (Exception e)
			{System.out.println(e);
			}
		
		t1.setName("thread 1");
		t2.setName("thread 2");
		System.out.println(t1.getName());
		System.out.println(t2.getName());
		
		System.out.println("thread 1 priority " + t1.getPriority());
		System.out.println("thread 2 priority " + t2.getPriority());
		
		}
				
	}


