package Multi_thread;

//import java.util.Scanner;

class Table
{
//	void printTable(int n)
	synchronized void printTable(int n)
	{	for (int i=0;i<5;i++)
		{	
			System.out.println(n*i);}

		try 
		{
				Thread.sleep(2000);
	
		}catch (Exception e)
			{	System.out.println(e);}

	}
}

class myThread1 extends Thread
{	
	Table t;
	myThread1(Table t)
	{	this.t=t;
	
	}
	
	public void run()
	{
		t.printTable(5);
		
	}
}


class myThread2 extends Thread
{	
	Table t;
	myThread2(Table t)
	{	this.t=t;
	
	}
	
	public void run()
	{
		t.printTable(100);
		
	}
}



public class without_sync {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Table c = new Table();
		myThread1 t1=new myThread1(c);
		myThread1 t2=new myThread1(c);
		t1.start();
		t2.start();
		
		
	}
}

