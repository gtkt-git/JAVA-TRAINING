package Multi_thread;



public class thread_demo extends Thread {

	public void run()
	{
		System.out.println("thread is running");
	
	for (int i=0;i<20;i++)
	{	if (i%2==0)
		{	System.out.println(i);}
	}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		thread_demo t = new thread_demo();
		t.start();
			
		
	}

}
