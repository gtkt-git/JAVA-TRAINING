package Multi_thread;




public class sys_memory {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Runtime r = Runtime.getRuntime();
		System.out.println("total memory: " + r.totalMemory());
		System.out.println("free memory: " + r.freeMemory());
		
		for (int i=0;i<1000;i++)
		{	
				new sys_memory();
		}
		
		System.out.println("after creating 1000 instance, free memory: " + r.freeMemory());
		System.gc();
		System.out.println("after gc, free memory: " + r.freeMemory());
		
	}

}
