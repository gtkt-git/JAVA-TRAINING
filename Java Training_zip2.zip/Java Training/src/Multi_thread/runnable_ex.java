package Multi_thread;
import java.util.*;


public class runnable_ex implements Runnable {
	public void run()
	{	
		Scanner s = new Scanner(System.in);
		
		System.out.println("enter the value n: ");
		int n = s.nextInt();
		
	for (int i=0;i<n;i++)
	{	
			System.out.println(i*i);
	}
		
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		runnable_ex r =new runnable_ex();
		Thread t = new Thread(r,"My Thread");
		t.start();
		System.out.println(t.getName());
	}

}
