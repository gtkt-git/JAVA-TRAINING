
public class switch_case {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int basic_sal, hra;
		basic_sal=2800;
//		hra=	15000;

		switch (basic_sal)
		{
		case 1500: 
			hra=basic_sal*10/100;
			break;
		case 2500:
			hra=basic_sal*20/100;
			break;
		case 3500:
			hra=basic_sal*30/100;
			break;
		default: 
			hra=basic_sal*50/100;
		}
		System.out.println("HRA is : " + hra);
		
		}
	
	}


