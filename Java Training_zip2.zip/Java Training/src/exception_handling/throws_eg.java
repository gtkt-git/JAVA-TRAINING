package exception_handling;
import java.io.*;

public class throws_eg {

	void M() throws IOException
	{ System.out.println("Device operation performed");}
	
	void M1() throws ClassNotFoundException
	{ System.out.println("M1 operation performed");}
		
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub

		throws_eg o = new throws_eg();
		o.M();
		o.M1();
		System.out.println("normal flow");
		
	}

}
