package exception_handling;

public class exception_demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
		int salary=25000;
		System.out.println("Salary: " + salary);
		int hra=salary*15/0;
		System.out.println("hra: " + hra);
		} catch (ArithmeticException e)
//		{			System.out.println("my arithmetic error message");}
		{			System.out.println(e);}
		System.out.println("executing remainder of code after the exception");
	}

}
