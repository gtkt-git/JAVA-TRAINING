package exception_handling;

class invalidAgeException extends Exception
{	
	public invalidAgeException(String str)
	{	super(str);
	
	}

}
public class custom_exception {

	static void validate(int age) throws invalidAgeException
	{	if (age < 18) 
	{	throw new invalidAgeException("age is not valid");	}
	else {	System.out.println("Welcome to vote ");	}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try 
		{
//			validate(15);
			validate(19);
		} catch (invalidAgeException e)
		{
			System.out.println(e);
			
		}
		System.out.println("rest of code ");
	}

}
