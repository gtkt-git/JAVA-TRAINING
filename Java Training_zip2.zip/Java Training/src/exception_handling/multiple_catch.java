package exception_handling;

public class multiple_catch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int reg_id[] = new int[6];	
			String name=null;
			int str_length=name.length();
			System.out.println("String length: " + str_length);
			reg_id[7]=43/0;
//			System.out.println("Value is :" + reg_id[5]);
			} 
		/*
			catch(IndexOutOfBoundsException e)
			{	System.out.println(e);  }
		
		 	catch(ArithmeticException e)
			{	System.out.println(e);  }
		
			catch (NullPointerException e)
			{	System.out.println(e);	}
	
			catch(Exception e)
			{	System.out.println(e);  }
		*/
			finally
			{ 	System.out.println("Finally with Exception");	}
		
		System.out.println("rest of the code");

		}	
}


