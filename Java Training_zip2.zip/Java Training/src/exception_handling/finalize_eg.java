package exception_handling;

public class finalize_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		finalize_eg o = new finalize_eg();
		System.out.println("hash code " + o.hashCode());
		o=null;
		System.gc();
		System.out.println("end of garbage collection ");	
	}

	protected void finalize() {
		// TODO Auto-generated method stub

		
		System.out.println("called finalize method ");
//		o=null;
//		System.gc();
			
	}
}
