package exception_handling;
import java.io.*;

class Parent
{	void msg() throws IOException
	{	System.out.println("Parent method ");
	
}
}

public class override_exception extends Parent {

	void msg() throws IOException
	{	System.out.println("Child method ");	}
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		Parent p = new override_exception();
		p.msg();
		
	}

}
