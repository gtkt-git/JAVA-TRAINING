package exception_handling;



public class num_format_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		String s="s1";
		try {
		int decimal_example = Integer.parseInt("20");
		int signed_positive_ex = Integer.parseInt("20");
		int signed_negative_ex = Integer.parseInt("-20");
		int s=Integer.parseInt("null");
		
		System.out.println("Value is :" + decimal_example);
		System.out.println("Positive Value is :" + signed_positive_ex);
		System.out.println("Negative Value is :" + signed_negative_ex);
		} catch(NumberFormatException e)
		{	System.out.println(e);  }
		
		System.out.println("rest of the code");

}
}