package exception_handling;

public class throw_eg2 {

	static void checkMark(int mark)
	{
		if (mark < 50)
		{	throw new ArithmeticException("Mark less than 50 - not qualified"); }
		else {System.out.println("Success");}
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		checkMark(25);
		
		
	}

}
