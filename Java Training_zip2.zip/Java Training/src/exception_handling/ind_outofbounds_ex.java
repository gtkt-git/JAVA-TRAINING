package exception_handling;

public class ind_outofbounds_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int reg_id[] = new int[5];	
			System.out.println("Value is :" + reg_id[5]);
		} catch(IndexOutOfBoundsException e)
		{	System.out.println(e);  }
		
		System.out.println("rest of the code");

}

}
