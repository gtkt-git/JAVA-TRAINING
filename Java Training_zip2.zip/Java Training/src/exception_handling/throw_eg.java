package exception_handling;

public class throw_eg {

	static void checkAge(int age)
	{
		if (age < 18)
		{	throw new ArithmeticException("Access denied - must be at least 18 years old"); }
		else {System.out.println("Success");}
	
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		checkAge(10);
		
		
	}

}
