package exception_handling;


public class null_pointer_exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		String name=null;
		int str_length=name.length();
		System.out.println("String length: " + str_length);
		} catch (NullPointerException e)
			{	System.out.println(e);	}
		
		System.out.println("Remainder of code");
	}

}
