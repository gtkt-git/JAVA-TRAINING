package OOPS;
import java.util.Scanner;
class stu {

	String university,addr,dept;
	int reg_no;
	
	stu(int reg_no, String university)
	{
		this.reg_no=reg_no;
		this.university=university;

	}
	
	stu()
	{
		System.out.println("Displaying default constructor");
	}
	
	stu(int reg_no, String university,String addr,String dept)
	{
		this.reg_no=reg_no;
		this.university=university;
		this.addr=addr;
		this.dept=dept;

	}
	
	
	void display()
	{
		
		System.out.println("UNI:" + university);
		System.out.println("REG NO:" + reg_no);
		System.out.println("Addr:" + addr);
		System.out.println("Dept: " + dept);
//		System.out.println("Emp ID: " + emp_id);
	}
}
	
	public class const_overload 
	{	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*		
		int emp_id;
		Scanner s = new Scanner(System.in);
		String emp_name;	
		System.out.println("pls enter emp id: ");
		emp_id=s.nextInt();
		System.out.println("pls enter emp name: ");
		emp_name=s.next();
*/	
		
//		firm a = new firm();
		stu a = new stu();
		stu b = new stu(111,"UNI");
		stu c = new stu(111,"UNI","ADDR","DEPT");
		a.display();
		b.display();
		c.display();
//		System.out.println("Employee Name:" + emp_name);
//		System.out.println("Emp ID: " + emp_id);
	}
	}

