package OOPS;

class Emp6
{
	private int emp_id;
	private String name,dept;
	
	public void setEmp_id(int emp_id)
	{	this.emp_id=emp_id;	}	

	public void setEmp_name(String name)
	{	this.name=name;	}	

	public void setEmp_dept(String dept)
	{	this.dept=dept;	}	
	
	
	public int getEmp_id()
	{	return this.emp_id;	}	

	public String getEmp_name()
	{	return this.name;	}	

	public String getEmp_dept()
	{	return this.dept;	}	
	
	
	
}

public class emp_bean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp6 e = new Emp6();
		e.setEmp_id(111);
		e.setEmp_name("AAA");
		e.setEmp_dept("DEP1");
		
		System.out.println("EMP_id: " + e.getEmp_id());
		System.out.println("EMP_name: " + e.getEmp_name());
		System.out.println("DEPT: " + e.getEmp_dept());
		
		
		
	}

}
