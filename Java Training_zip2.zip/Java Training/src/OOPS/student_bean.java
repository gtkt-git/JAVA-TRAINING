package OOPS;

class Stu6
{
	private int student_id;
	private String name,dept;
	
	public void setStudent_id(int student_id)
	{	this.student_id=student_id;	}	

	public void setStudent_name(String name)
	{	this.name=name;	}	

	public void setStudent_dept(String dept)
	{	this.dept=dept;	}	
	
	
	public int getStudent_id()
	{	return this.student_id;	}	

	public String getStudent_name()
	{	return this.name;	}	

	public String getStudent_dept()
	{	return this.dept;	}	
	
}

public class student_bean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stu6 e = new Stu6();
		e.setStudent_id(111);
		e.setStudent_name("AAA");
		e.setStudent_dept("DEP1");
		
		System.out.println("Student_id: " + e.getStudent_id());
		System.out.println("Student_name: " + e.getStudent_name());
		System.out.println("DEPT: " + e.getStudent_dept());
		
	}

}
