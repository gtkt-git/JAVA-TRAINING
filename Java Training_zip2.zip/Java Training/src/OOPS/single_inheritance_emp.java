package OOPS;
import java.util.Scanner;
class Emp2
{
	int emp_id;
	String name,dept;
	boolean result;
	char grade;
	Scanner s = new Scanner(System.in);
	
	void getData()
	{
	System.out.println("Enter the Emp ID: ");
	emp_id=s.nextInt();
	System.out.println("pls enter EMP name: ");
	name=s.next();
	System.out.println("pls enter DEPT ");
	dept=s.next();
//	System.out.println("pls enter Mark2: ");
//	mark2=s.nextInt();
//	System.out.println("pls enter Mark3: ");
//	mark3=s.nextInt();
	
	}
}

class marklist2 extends Emp2
{
	int tot,avg;
	
//	void m_list()
//	{	tot=mark1+mark2+mark3;
//		avg=tot/3;
		
//		if (avg>=80)
//		{grade='A';}
//		else if (avg>70 && avg<80)
//		{grade='B';}
//		else {grade='C';}
//	}
	
	void display()
	{
		
		System.out.println("emp id:" + emp_id);
		System.out.println("name:" + name);
		System.out.println("dept:" + dept);

	}
}
	

public class single_inheritance_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		marklist2 m = new marklist2();
		m.getData();
//		m.m_list();
		m.display();
				
	
}
}
