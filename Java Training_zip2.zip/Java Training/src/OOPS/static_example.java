package OOPS;
import java.util.Scanner;

class leap_yr
{	static int year=2020;

	static void year()
	{	
//	
//	System.out.println("Enter the year: ");
//	year=s.nextInt();

	
	if (year%4 == 0)
	{	System.out.println(year + "leap year: ");}
	else
	{	System.out.println(year + "not a leap year: ");
	}
	
	}

	
public class static_example {

//	public static void main(String[] args) {
	public void main(String[] args) {		
		
		// TODO Auto-generated method stub
		year();
				
	}
}
}
