package OOPS;

class parent
{	void show()
	{		System.out.println("from Parent");
	
	}

	int calc(int a,int b)
	{	return (a+b);
	
	}
}

class child
{	void show()
	{		System.out.println("from child");
	
	}

	int calc(int a,int b)
	{	return (a*b);
	
	}
}


public class overriding_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		child c = new child();
		c.show();
		int mul_result=c.calc(3,5);
		System.out.println("multiplication : " + mul_result);		
	}

}
