package OOPS;
import java.util.Scanner;
class firm1 {

	String city,company_name,dept,emp_name;
	int emp_id;
	
	firm1(String company_name, String city, String dept)
	{
		this.company_name=company_name;
		this.city=city;
//		this.emp_name=emp_name;
		this.dept=dept;
//		this.emp_id=emp_id;
	}
	
	firm1()
	{
		System.out.println("Displaying default constructor");
	}
	
	void display()
	{
		
		System.out.println("COMPANY:" + company_name);
		System.out.println("City:" + city);
//		System.out.println("Employee Name:" + emp_name);
		System.out.println("Dept: " + dept);
//		System.out.println("Emp ID: " + emp_id);
	}
}
	
	public class company_v2 
	{	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int emp_id;
		Scanner s = new Scanner(System.in);
		String emp_name;	
		System.out.println("pls enter emp id: ");
		emp_id=s.nextInt();
		System.out.println("pls enter emp name: ");
		emp_name=s.next();
	
		
//		firm a = new firm();
		firm1 b = new firm1("COMPANY","CITY","DEPT");
		b.display();
		System.out.println("Employee Name:" + emp_name);
		System.out.println("Emp ID: " + emp_id);
	}
	}

