package OOPS;

class Bank1 {

	String ifsc,address,name;
	int zipcode;
	
	Bank1(String ifsc_code, String addr, String name1,int zip)
	{
		ifsc=ifsc_code;
		address=addr;
		name=name1;
		zipcode=zip;
	}
	
	Bank1()
	{
		System.out.println("default");
	}
	
	void display()
	{
		
		System.out.println("IFSC:" + ifsc);
		System.out.println("Name:" + name);
		System.out.println("Address:" + address);
		System.out.println("Zip: " + zipcode);

	}
}
	
	public class Bank 
	{	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bank1 a = new Bank1();
		Bank1 b = new Bank1("IFSC","ADDR","NAME",2235);
		b.display();
	}
	}

