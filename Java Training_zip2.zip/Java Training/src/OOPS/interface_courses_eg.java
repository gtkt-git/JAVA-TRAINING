package OOPS;

/*
 * interface -> courses
variables ->id,name
method  -> course_fee()

B_Tech -> 

M_Tech  ->

Medical ->
 * 
 */


interface courses
{	
	int course_fee(int id,String name);
	default void interface_msg()
	{		System.out.println("interface message here");
	}
}

class fees implements courses
{	public int course_fee(int id,String name)
	{	//name="BTech";
		if (name == "BTech")
		{	return 1000;	}
		else if (name=="MTech")
		{	return 2000	;	}
		else 
		{	return 3000;	}
	
	}

}

public class interface_courses_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		fees f = new fees();
		
		f.interface_msg();
		
		System.out.println("BTECH Fee is : " + f.course_fee(111,"BTech"));
		System.out.println("MTECH Fee is : " + f.course_fee(222,"MTech"));
		System.out.println("MEDICAL Fee is : " + f.course_fee(111,"MED"));
	}

}
