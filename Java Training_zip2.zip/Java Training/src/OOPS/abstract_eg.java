package OOPS;

abstract class bank3
{
	bank3()
	{	System.out.println("bank3 constructor");}
		
	abstract int rate_of_int();
//	{	System.out.println("H1");
//	}


	void show()
	{	System.out.println("concrete method");}
		
}

class HDFC extends bank3
{ 	int rate_of_int()
	{	return 12;}
}

class ICICI extends bank3
{ 	int rate_of_int()
	{	return 14;}
}

public class abstract_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HDFC h = new HDFC();
		ICICI i = new ICICI();
//		int interest=h.rate_of_int;
		
		System.out.println("HDFC INT: " + h.rate_of_int());
		
		System.out.println("ICICI INT: " + i.rate_of_int());
				
	}

}
