package OOPS;
import java.util.Scanner;
class Student
{
	int reg_no,mark1,mark2,mark3,tot,avg;
	String name;
	boolean result;
	char grade;
	Scanner s = new Scanner(System.in);
	
	void getData()
	{
	System.out.println("Enter the Reg no: ");
	reg_no=s.nextInt();
	System.out.println("pls enter name: ");
	name=s.next();
	System.out.println("pls enter Mark1: ");
	mark1=s.nextInt();
	System.out.println("pls enter Mark2: ");
	mark2=s.nextInt();
	System.out.println("pls enter Mark3: ");
	mark3=s.nextInt();
	
	}
}
class marklist extends Student
{
	int tot,avg;
	
	void m_list()
	{	tot=mark1+mark2+mark3;
		avg=tot/3;
		
		if (avg>=80)
		{grade='A';}
		else if (avg>70 && avg<80)
		{grade='B';}
		else {grade='C';}
	}
	
	void display()
	{
		
		System.out.println("regno:" + reg_no);
		System.out.println("name:" + name);
		System.out.println("mark1:" + mark1);
		System.out.println("mark2: " + mark2);
		System.out.println("mark3: " + mark3);
		System.out.println("total: " + tot);
		System.out.println("avg: " + avg);
		System.out.println("grade: " + grade);
	}
}
	

public class single_inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		marklist m = new marklist();
		m.getData();
		m.m_list();
		m.display();
				
	
}
}
