package OOPS;

interface printer
{	void print();

}

interface scanner extends printer
{	void scan();

}

class interface_demo implements scanner
{	
	@override
	
	public void print()
	{	System.out.println("printing...");

}

public class interface_ext_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HDFC5 h = new HDFC5();
		System.out.println("interest is : " + h.interest());
		
		
	}

}
