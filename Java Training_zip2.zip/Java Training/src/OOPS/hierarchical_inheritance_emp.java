package OOPS;
import java.util.Scanner;
class Emp3
{
	int emp_id,mark1,mark2,tot,avg;
	String name,dept;
	String result;
//	boolean result;
	char grade;
	Scanner s = new Scanner(System.in);
	
	void getData()
	{
	System.out.println("Enter the Emp ID: ");
	emp_id=s.nextInt();
	System.out.println("pls enter EMP name: ");
	name=s.next();
	System.out.println("pls enter DEPT ");
	dept=s.next();
	System.out.println("pls enter Mark1: ");
	mark1=s.nextInt();
	System.out.println("pls enter Mark2: ");
	mark2=s.nextInt();
	
	}
	
	void m_list()
	{	
//		int tot,avg;
		
		tot=mark1+mark2;
		avg=tot/2;
	}
		
		
//		if (avg>=80)
//		{grade='A';}
//		else if (avg>70 && avg<80)
//		{grade='B';}
//		else {grade='C';}
//	}
	
}

class result_cls extends Emp3
{

	
	void result()
	{

		
		if (mark1>=50 && mark2>=50)
			{result="PASS";}
		else {result="FAIL";}
		System.out.println("result:" + result);
	}
	
}
	
class grade_cls extends Emp3
{
//	char grade;
//	int avg;
	void grade()
	{
	
		if (avg>=80)
			{grade='A';}
		else {grade='B';}
	}
	
	void display()
	{
		
		System.out.println("emp id:" + emp_id);
		System.out.println("name:" + name);
		System.out.println("dept:" + dept);
		System.out.println("mark1:" + mark1);
		System.out.println("mark2:" + mark2);
		System.out.println("total:" + tot);
		System.out.println("grade:" + grade);
	}
}


public class hierarchical_inheritance_emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			
		result_cls r = new result_cls();
		grade_cls g = new grade_cls();
		r.getData();
		r.m_list();
		r.result();
		
		g.getData();
		g.m_list();
		g.grade();
		g.display();
				
	
}
}
