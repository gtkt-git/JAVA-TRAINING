package OOPS;
import java.util.Scanner;
class emp {

	String city,company_name,dept,emp_name;
	int emp_id;
	
	emp(int emp_id, String emp_name)
	{
		this.emp_id=emp_id;
		this.emp_name=emp_name;

	}
	
	emp()
	{
		System.out.println("Displaying default constructor");
	}
	
	emp(int emp_id, String emp_name,String dept,String company_name)
	{
		this.emp_id=emp_id;
		this.emp_name=emp_name;
		this.dept=dept;
		this.company_name=company_name;


	}
	
	
	void display()
	{
		
		System.out.println("COMPANY:" + company_name);
		System.out.println("Employee ID:" + emp_id);
		System.out.println("Emp Name:" + emp_name);
		System.out.println("Dept: " + dept);
//		System.out.println("Emp ID: " + emp_id);
	}
}
	
	public class const_overload_2 
	{	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

/*		
		int emp_id;
		Scanner s = new Scanner(System.in);
		String emp_name;	
		System.out.println("pls enter emp id: ");
		emp_id=s.nextInt();
		System.out.println("pls enter emp name: ");
		emp_name=s.next();
*/	
		
//		firm a = new firm();
		emp a = new emp();
		emp b = new emp(111,"EMPNAME");
		emp c = new emp(111,"EMPNAME","DEPT","COMPANY");
		a.display();
		b.display();
		c.display();
//		System.out.println("Employee Name:" + emp_name);
//		System.out.println("Emp ID: " + emp_id);
	}
	}

