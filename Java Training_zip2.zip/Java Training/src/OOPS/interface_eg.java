package OOPS;

interface bank8
{	long acctno=42713454545L;
	int interest();
}

class HDFC2 implements bank8
{	public int interest()
	{	return 15; }

}

public class interface_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HDFC2 h = new HDFC2();
		System.out.println("interest is : " + h.interest());
		
		
	}

}
