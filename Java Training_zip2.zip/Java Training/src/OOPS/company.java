package OOPS;

class firm {

	String city,company_name,dept,emp_name;
	int emp_id;
	
	firm(String company_name, String city,String emp_name, String dept,int emp_id)
	{
		this.company_name=company_name;
		this.city=city;
		this.emp_name=emp_name;
		this.dept=dept;
		this.emp_id=emp_id;
	}
	
	firm()
	{
		System.out.println("Displaying default constructor");
	}
	
	void display()
	{
		
		System.out.println("COMPANY:" + company_name);
		System.out.println("City:" + city);
		System.out.println("Employee Name:" + emp_name);
		System.out.println("Dept: " + dept);
		System.out.println("Emp ID: " + emp_id);
	}
}
	
	public class company 
	{	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		firm a = new firm();
		firm b = new firm("COMPANY","CITY","EMP-NAME","DEPT",2235);
		b.display();
	}
	}

