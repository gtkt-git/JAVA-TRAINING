package OOPS;

class Address2
{	String uni,dept,country;
	Address2(String uni,String dept, String country)
	{	this.uni=uni;
		this.dept=dept;
		this.country=country;
	}
}

class Stu5
{	int id;
	String name;
	Address2 address;
	Stu5(int id,String name,Address2 address)
	{	this.id=id;
		this.name=name;
		this.address=address;
	}

	void display()
	{	System.out.println(id + " " + name);
		System.out.println(address.uni+ " " +address.dept+ " " + address.country);
	}
}

public class aggregation_student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Address2 add1 = new Address2("UNI-1","DEPT1","SG");
		Address2 add2 = new Address2("UNI-2","DEPT2","MY");
		
		Stu5 emp1 = new Stu5(111,"Name1",add1);
		Stu5 emp2 = new Stu5(222,"Name2",add2);
		
		emp1.display();
		emp2.display();
		
		
	}

}
