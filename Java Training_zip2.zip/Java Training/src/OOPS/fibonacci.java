package OOPS;
import java.util.Scanner;

public class fibonacci
{	static void isArmstrong(int number)
	{	

	int check=0,sum=0,rem;
//	int tens=hundreds_mod/10;
//	int hundreds=year/100;
//	int ones=tens%10;
	
//	check=number;
	while (check<=number) 
	{
		rem=check%10;
		sum=sum+(rem*rem*rem);
		check=check/10;
		
	}
	if (sum==number)
	{System.out.println(number + "armstrong num");}
	else
	{System.out.println(number + " number ");
	 System.out.println(sum + " sum");
	
	System.out.println(number + "not armstrong ");}
	}
	
/*	
	int hundreds_cube=hundreds*hundreds*hundreds;
	int tens_cube=tens*tens*tens;
	int ones_cube=ones*ones*ones;
	
		
	if (hundreds + tens + ones == 0)
	{	System.out.println(year + "leap year: ");}
	else
	{	System.out.println(year + "not a leap year: ");
	}
	
	}
*/
	
//public class armstrong_static {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		System.out.println("Enter the number: ");
		Scanner s = new Scanner(System.in);
		int n=s.nextInt();
		armstrong_static.isArmstrong(n);
				
	}
}

