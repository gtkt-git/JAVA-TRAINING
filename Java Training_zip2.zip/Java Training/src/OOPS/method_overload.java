package OOPS;

class demo
{	int add(int num1, int num2)
	{
	return (num1-num2);
	}

	int add(int num1, int num2, int num3)
	{
		return (num1*num2*num3);
	}
	
	double add(double num1, double num2, double num3)
	{
		return (num1*num2/num3);
	}
	
}


public class method_overload {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		demo d = new demo();
		System.out.println(d.add(3, 5));
		System.out.println(d.add(3, 5,4));
		System.out.println(d.add(3.2, 5.4, 2.2));

	}

}
