package OOPS;

abstract class shape
{
	shape()	{}
//	{	System.out.println("shape constructor");}
		
	abstract String draw();
//	{	System.out.println("H1");
//	}

	void show()
	{	System.out.println("concrete method");}
		
}

class circle extends shape
{ 	
	circle()
	{	System.out.println("circle constructor");}
	
	String draw()
	{	return "drawing circle";}
}

class square extends shape
{ 	square()
	{	System.out.println("square constructor");}
	
	String draw()
	{	return "drawing square";}
}

class rect extends shape
{ 	rect()
	{	System.out.println("rect constructor");}
	
	String draw()
	{	return "drawing rect";}
}


public class abstract_shapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		circle c = new circle();
		square s = new square();
		rect r = new rect();
		
//		int interest=h.rate_of_int;
		
		System.out.println("task circle: " + c.draw());
		System.out.println("task rect: " + r.draw());
		System.out.println("task square: " + s.draw());
				
	}

}
