package OOPS;

class Address
{	String city,state,country;
	Address(String city,String state, String country)
	{	this.city=city;
		this.state=state;
		this.country=country;
	}
}

class Emp4
{	int id;
	String name;
	Address address;
	Emp4(int id,String name,Address address)
	{	this.id=id;
		this.name=name;
		this.address=address;
	}


	void display()
{		System.out.println(id + name);
		System.out.println(address.city+address.state+address.country);
}
}
public class aggregation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Address add1 = new Address("CITY1","STATE1","SG");
		Address add2 = new Address("CITY2","STATE2","MY");
		
		Emp4 emp1 = new Emp4(111,"Name1",add1);
		Emp4 emp2 = new Emp4(222,"Name2",add2);
		
		emp1.display();
		emp2.display();
		
		
	}

}
