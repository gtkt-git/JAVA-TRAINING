
public class if_elseif_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int basic_sal, hra;
		basic_sal=500;
//		hra=	15000;
		
		if (basic_sal>1000 && basic_sal<2000) 
			{hra=basic_sal*10/100;}
		else if (basic_sal>2000 && basic_sal<3000)
		{hra=basic_sal*20/100;}
		else if (basic_sal>3000 && basic_sal<4000)
		{hra=basic_sal*30/100;}

		else 
			{hra=basic_sal*50/100;}
		System.out.println("HRA is : " + hra);
		
		}
	
	}


