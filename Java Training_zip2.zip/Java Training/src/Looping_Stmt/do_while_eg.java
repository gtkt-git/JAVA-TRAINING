package Looping_Stmt;
import java.util.Scanner;
public class do_while_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner s = new Scanner(System.in);
		String emp_name,doj;
		char choice;
		int i,no_of_emp,emp_id;
		float basic_sal, hra,da,tax,pr;
		
//		i=0;
//		System.out.println("pls enter number of employees: ");
//		no_of_emp=s.nextInt();

		do //  while (i<no_of_emp)
		{	

		System.out.println("pls enter emp name: ");
		emp_name=s.next();
		
		System.out.println("pls enter emp ID: ");
		emp_id=s.nextInt();

		System.out.println("pls enter basic salary: ");
		basic_sal=s.nextFloat();
		
		if (basic_sal>1000 && basic_sal<2000) 
			{hra=basic_sal*10/100;
			 tax=basic_sal*5/100;}
		else if (basic_sal>2000 && basic_sal<3000)
			{hra=basic_sal*20/100;
			 tax=basic_sal*10/100;}
		else if (basic_sal>3000 && basic_sal<4000)
			{hra=basic_sal*30/100;
			 tax=basic_sal*15/100;}

		else 
			{hra=basic_sal*50/100;
			 tax=basic_sal*20/100;}
		
		float total_earnings=basic_sal+hra;
		float total_ded=tax;
		
		float gross_sal=total_earnings-total_ded;
		
		
		System.out.println("JAN PAYSLIP");
		System.out.println("============");
		System.out.println("EMP NAME: " + emp_name + "       EMP ID: " + emp_id);
		System.out.println("BASIC SALARY: " + basic_sal);
		System.out.println("============");
		System.out.println("EMP HRA: " + hra + "      EMP TAX: " + tax);
		System.out.println("TOTAL SALARY: " + total_earnings);
//		System.out.println("EMP HRA: " + hra + "EMP TAX: " + tax);
		System.out.println("GROSS SALARY: " + gross_sal);

//		i++;
		System.out.println("do u want to continue? (Y/N) ");
		choice=s.next().charAt(0);
		} while (choice!='N');

	}

}
