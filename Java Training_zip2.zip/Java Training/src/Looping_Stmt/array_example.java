package Looping_Stmt;
import java.util.Scanner;
public class array_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no_of_emp;
		Scanner s = new Scanner(System.in);
//		String emp_name,doj;
		char choice;
		System.out.println("pls enter number of employees: ");
		no_of_emp=s.nextInt();

		int emp_id[] = new int[no_of_emp];
		String emp_name[] = new String[no_of_emp];
		String dept[] = new String[no_of_emp];
		System.out.println("pls enter details: ");
		
		for (int i=0;i<no_of_emp;i++)
			{	System.out.println("pls enter emp id: ");
				emp_id[i]=s.nextInt();

				System.out.println("pls enter emp name: ");
				emp_name[i]=s.next();
			}
		System.out.println("Employee ID: ");
		
		for (int i: emp_id)
		{	System.out.println("emp id: " + i);

		}
		System.out.println("Employee name: ");
		
		for (String i: emp_name)
		{	System.out.println("emp name: " + i);

		}
	}

}
