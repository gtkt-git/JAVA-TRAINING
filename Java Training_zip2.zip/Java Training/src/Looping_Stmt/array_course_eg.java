package Looping_Stmt;
import java.util.Scanner;

/*
 * Enter the no of courses:- 5

course name1: MCA
course name2: MBA
course name3: MS
course name4: MA
course name5: MD

from susila.p to everyone:    5:02 PM
Registered courses are:

course name1: MCA
course name2: MBA
course name3: MS
course name4: MA
course name5: MD

 */
public class array_course_eg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no_of_emp;
		Scanner s = new Scanner(System.in);
//		String emp_name;
		char choice;
		
		do //  
		{	
		System.out.println("pls enter number of courses: ");
		no_of_emp=s.nextInt();

		int reg_id[] = new int[no_of_emp];
		String student_name[] = new String[no_of_emp];
		String dept[] = new String[no_of_emp];
		String result[] = new String[no_of_emp];
		System.out.println("------------------ ");
		
		System.out.println("pls enter details: ");
		for (int i=0;i<no_of_emp;i++)
			{	
	//			System.out.println("student reg number: ");
	//			reg_id[i]=s.nextInt();

				System.out.println("course name: ");
				student_name[i]=s.next();
	//			System.out.println("dept: ");
	//			dept[i]=s.next();
	//			System.out.println("result: ");
	//			result[i]=s.next();

			}
		
		System.out.println("------------------ ");
		System.out.println("You entered the following: ");
		int count=0;
		for (int i=0;i<no_of_emp;i++)
		{	
//			System.out.println("student reg number: " + reg_id[i]);
//			reg_id[i]=s.nextInt();
			count=count+1;
			
			System.out.println("course name: " + count + " " + student_name[i]);
//			student_name[i]=s.next();
//			System.out.println("dept: " + dept[i]);
//			dept[i]=s.next();
//			System.out.println("result: " + result[i]);
//			result[i]=s.next();
//			System.out.println("------------------ ");
		}
		
		System.out.println("do u want to continue? (Y/N) ");
		choice=s.next().charAt(0);
		} while (choice!='N');
	}
	}

