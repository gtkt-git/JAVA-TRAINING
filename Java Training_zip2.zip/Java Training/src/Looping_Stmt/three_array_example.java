package Looping_Stmt;
import java.util.*;
public class three_array_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no_of_row, no_of_col;
		Scanner s = new Scanner(System.in);
//		String emp_name;
		char choice;
//		no_of_row=0;
//		no_of_col=0;
//		int table[][] = new int[no_of_row][no_of_col];
		System.out.println("pls enter number of rows: ");
		no_of_row=s.nextInt();

		System.out.println("pls enter number of columns: ");
		no_of_col=s.nextInt();
		
		int table1[][] = new int[no_of_row][no_of_col];
		int table2[][] = new int[no_of_row][no_of_col];
		int table3[][] = new int[no_of_row][no_of_col];
		
		System.out.println("pls enter your Table 1 data: ");
		
		for (int i=0;i<no_of_row;i++)		// row
		{ for (int j=0;j<no_of_col;j++)
			{ table1[i][j]=s.nextInt();		//column
			
			}
		}
		
		System.out.println("pls enter your Table 2 data: ");
		
		for (int i=0;i<no_of_row;i++)		// row
		{ for (int j=0;j<no_of_col;j++)
			{ table2[i][j]=s.nextInt();		//column
			
			}
		}

		System.out.println("Displaying Table 3 data (totals): ");
		
		for (int i=0;i<no_of_row;i++)		// row
		{ for (int j=0;j<no_of_col;j++)
			{ table3[i][j]= table1[i][j]+table2[i][j];		//column
			System.out.print(table3[i][j] + " ");
			
			}
			System.out.println();
		}
		
		
	}
}

