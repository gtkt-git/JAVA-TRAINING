package Looping_Stmt;
import java.util.Scanner;
public class array_example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no_of_emp;
		Scanner s = new Scanner(System.in);
//		String emp_name;
		char choice;
		
		do //  
		{	
		System.out.println("pls enter number of students: ");
		no_of_emp=s.nextInt();

		int reg_id[] = new int[no_of_emp];
		String student_name[] = new String[no_of_emp];
		String dept[] = new String[no_of_emp];
		String result[] = new String[no_of_emp];
		System.out.println("------------------ ");
		
		System.out.println("pls enter details: ");
		for (int i=0;i<no_of_emp;i++)
			{	System.out.println("student reg number: ");
				reg_id[i]=s.nextInt();

				System.out.println("name: ");
				student_name[i]=s.next();
				System.out.println("dept: ");
				dept[i]=s.next();
				System.out.println("result: ");
				result[i]=s.next();

			}
		
		System.out.println("------------------ ");
		System.out.println("You entered the following: ");
		for (int i=0;i<no_of_emp;i++)
		{	System.out.println("student reg number: " + reg_id[i]);
//			reg_id[i]=s.nextInt();

			System.out.println("name: " + student_name[i]);
//			student_name[i]=s.next();
			System.out.println("dept: " + dept[i]);
//			dept[i]=s.next();
			System.out.println("result: " + result[i]);
//			result[i]=s.next();
			System.out.println("------------------ ");
		}
		
		System.out.println("do u want to continue? (Y/N) ");
		choice=s.next().charAt(0);
		} while (choice!='N');
	}
	}

