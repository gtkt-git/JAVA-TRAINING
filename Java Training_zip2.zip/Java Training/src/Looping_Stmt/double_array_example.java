package Looping_Stmt;
import java.util.*;
public class double_array_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no_of_row, no_of_col;
		Scanner s = new Scanner(System.in);
//		String emp_name;
		char choice;
//		no_of_row=0;
//		no_of_col=0;
//		int table[][] = new int[no_of_row][no_of_col];
		System.out.println("pls enter number of rows: ");
		no_of_row=s.nextInt();

		System.out.println("pls enter number of columns: ");
		no_of_col=s.nextInt();
		
		int table[][] = new int[no_of_row][no_of_col];
		
		System.out.println("pls enter your data: ");
		
		for (int i=0;i<no_of_row;i++)		// row
		{ for (int j=0;j<no_of_col;j++)
			{ table[i][j]=s.nextInt();		//column
			
			}
		}
		
		
		for (int i=0;i<no_of_row;i++)		// row
		{ for (int j=0;j<no_of_col;j++)
			{ System.out.print(table[i][j] + " ");		//column
			
			}
			System.out.println();
		}
		
		
	}
}

