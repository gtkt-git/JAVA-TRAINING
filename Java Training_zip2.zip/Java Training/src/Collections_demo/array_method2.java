package Collections_demo;

import java.util.ArrayList;

public class array_method2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> a1 = new ArrayList();

		
		a1.add("name1");
		a1.add("name2");
		a1.add("name3");
		a1.add("name4");
		a1.add("name5");
		
		System.out.println("initial list of elements" + a1);
		
		a1.remove("name2");
		System.out.println("after remove name2 " + a1);
		
		a1.remove(0);
		System.out.println("after element index 0 " + a1);
		
		ArrayList<String> a12 = new ArrayList();
		a12.add("array12-name1");
		a12.add("array12-name2");
		a1.addAll(a12);
		System.out.println("update list " + a1);
		
		
		a1.removeAll(a12);
		System.out.println("after removeAll-a12 " + a1);
		
		a1.clear();
		System.out.println("after clear " + a1);
		
	}

}
