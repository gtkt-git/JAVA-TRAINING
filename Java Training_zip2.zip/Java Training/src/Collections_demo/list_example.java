package Collections_demo;

import java.util.*;


public class list_example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList emp =new ArrayList();
		emp.add("1011");
		emp.add(3500);
		emp.add(6.18);
		
		System.out.println(emp);
		
		
		Iterator i = emp.iterator();
		while (i.hasNext())
		{	System.out.println(i.next());
		
		}
	}

}
