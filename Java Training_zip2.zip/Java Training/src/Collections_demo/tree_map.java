package Collections_demo;
import java.util.*;

/*		stores unique key value
 * 
 * 
 */
public class tree_map {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeMap<Integer,String> tm = new TreeMap<Integer,String>();
		tm.put(1011, "name1");
		tm.put(1022, "name2");
		tm.put(1033, "name3");		// not stored
		tm.put(1033, "name3");		// not stored, skipped
		tm.put(1033, "name5");		// stored
		tm.put(1044, "name4");
		tm.put(1055, null);
		
		for (Map.Entry m: tm.entrySet())
		{	 System.out.println(m.getKey() + " " + m.getValue());
		
		}
		
		tm.remove(1011);
		System.out.println("after removing 1011");
		for (Map.Entry m: tm.entrySet())
		{	 System.out.println(m.getKey() + " " + m.getValue());
		
		}
 
		System.out.println("descending order " + tm.descendingMap());
		System.out.println("head map " + tm.headMap(1033,true));	// selects <= key value given
		System.out.println("tail map " + tm.tailMap(1033,true));	// selects >= key value given
		System.out.println("sub map " + tm.subMap(1022,false,1044,true)); // selects range >1022 and <=1044
		
	 
	}
}
