package Collections_demo;

import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

/*	Stack allows data of varied type to be stored e.g. String, integer.
 * 	LIFO structure.
 * 	Methods available are push, pop, Iterator, hasNext, next.
 * 
 */

public class stack_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Stack Stu = new Stack();
		Stu.push("element1");
		Stu.push(2);
		Stu.push(3.2);
		Stu.push("4");
		System.out.println(Stu);
		System.out.println("the element at top of stack is: " + Stu.peek());
		Stu.pop(); // LIFO so "4" is removed 
		
//		Stu.peek();
		
		Iterator i = Stu.iterator();
		while (i.hasNext())
		{	System.out.println(i.next());
		
		}
		
		System.out.println("after 4 removed, the element at top of stack is: " + Stu.peek());
	}
	
		
	}


