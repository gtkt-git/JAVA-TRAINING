package Collections_demo;

import java.util.*;
/*
 * Queue stores data of 1 data type eg. only integer, String in the queue.
 * Data elements are sorted in ascending order.
 * Can have duplicate elements.
 * FIFO structure.
 */
public class queue_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PriorityQueue emp = new PriorityQueue();
		
		emp.add(1011);
		emp.add(3500);
		emp.add(6);
		emp.add(7);
		emp.add(3500);

		/*
		emp.add("1011");	// emp.add(1011);
		emp.add("3500");	// emp.add(3500);
		emp.add("6.18");	// emp.add(6);
		emp.add("6.18");	// emp.add(7);
		emp.add("last element");	
		*/
		System.out.println("head of queue: " + emp.element());

//		Iterator i = emp.iterator();
		System.out.println("queue elements are: ");
		Iterator i = emp.iterator();
		while (i.hasNext())
		{	System.out.println(i.next());
		
		}
		
		emp.remove();
		
		System.out.println("after removing...");
		
		Iterator j = emp.iterator();
		
		while (j.hasNext())
		{	System.out.println(j.next());
		
		}

	}
		
		
		
	}
