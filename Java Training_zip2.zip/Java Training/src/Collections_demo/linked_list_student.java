package Collections_demo;

import java.util.*;

class Student2
{	int id;
	String name,course;
	
	public Student2(int id,String name,String course)
	{	this.id=id;
		this.name=name;
		this.course=course;
			
	}

}

public class linked_list_student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Student2> list=new LinkedList<Student2>();
		
		Student2 b1=new Student2(111,"name1","course1");
		Student2 b2=new Student2(222,"name2","course2");
		
		list.add(b1);
		list.add(b2);
		
//		for (Student2 b:list)	// for data-type var-name collection-name
//		{	 
//		System.out.println("ID:"+ b.id +" NAME: "+b.name + " COURSE: " + b.course);
//		}
		
		Iterator i = list.iterator();
		while (i.hasNext())
		{	System.out.println(i.next());
		
		}		
//		
		
	}

}
