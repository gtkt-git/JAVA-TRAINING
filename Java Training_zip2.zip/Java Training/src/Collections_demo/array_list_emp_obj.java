package Collections_demo;

import java.util.*;

class Emp
{	int age,salary;
	String name,dept;
	
	Emp(String name,int age,int salary,String dept)
	{
		this.salary=salary;
		this.name=name;
		this.age=age;
		this.dept=dept;
	}
	
}

public class array_list_emp_obj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Emp e1 = new Emp("name1",19,3000,"dept1");
		Emp e2 = new Emp("name2",20,2400,"dept2");
		Emp e3 = new Emp("name3",21,5000,"dept3");
		
		ArrayList<Emp> a1 = new ArrayList();
		a1.add(e1);
		a1.add(e2);
		a1.add(e3);
		
		Iterator i = a1.iterator();
		while (i.hasNext())
		{	
			Emp e =(Emp)i.next();
			
			System.out.println(e.name + " " + e.age + " " + e.salary + " " + e.dept);
		
		}
	
	}
}
