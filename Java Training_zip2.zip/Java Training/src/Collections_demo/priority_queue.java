package Collections_demo;

import java.util.*;

public class priority_queue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		PriorityQueue<String> q = new PriorityQueue<String>();
        q.add("Ravi");
        q.add("Ravi");
        q.add("Ajay");
        q.add("Anuj");
        q.add("name5");
        
        System.out.println("Head of Queue:"+q.element());
        System.out.println("Head of Queue:"+q.peek());
        System.out.println("Queue iteration :");
        
        Iterator i = q.iterator();
		while (i.hasNext())
		{	
			System.out.println(i.next());
			

		}
//        hs.add(null);
		System.out.println("===========");
		q.poll();
		q.remove();
		
        Iterator j = q.iterator();
		while (j.hasNext())
		{	
			System.out.println(j.next());
			

		}
	
	}

}
