package Collections_demo;

import java.util.*;

/*	Set stores only 1 null value. 
 *  No duplicate elements allowed.
 *  Can store elements of varied data type e.g. String, integer.
 *  No sorting but stores elements in reverse order of adding to the Set.
 */

public class hash_set_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet set = new HashSet();
		set.add("name1");
		set.add("name2");
		set.add(123);
		set.add("name3");
		set.add("name3");
		set.add("name3");
		set.add(null);
		set.add(null);
		
		Iterator i = set.iterator();
		while (i.hasNext())
		{	System.out.println(i.next());
		
		}
		
	}

}
