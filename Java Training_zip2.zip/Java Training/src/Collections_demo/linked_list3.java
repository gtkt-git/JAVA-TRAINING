package Collections_demo;

import java.util.Collections;
import java.util.LinkedList;

public class linked_list3 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList ll =new LinkedList<String>();
        
        ll.add("Ravi");
        ll.add("Vijay");
        ll.add("Ajay");
        ll.add("Anuj");
        ll.add("Gaurav");
        ll.add("Harsh");
        ll.add("Virat");
        ll.add("Gaurav");
        ll.add("Harsh");
        ll.add("Amit");
        
        System.out.println("Initial Elements:"+ll);
        
 //       ll.set(2, "arul");
        ll.set(2, "Arul");
        System.out.println("Initial Elements:"+ll);
        
        Collections.sort(ll);
        System.out.println("After sorting:"+ll);
        
        
		
		
	}

}
