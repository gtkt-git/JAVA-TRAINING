package Collections_demo;

import java.util.*;

public class array_methods {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> a1 = new ArrayList();
		System.out.println("initial list of elements" + a1);
		
		a1.add("name1");
		a1.add("name2");
		a1.add("name3");
		
		System.out.println("after adding..." + a1);
		ArrayList<String> a12 = new ArrayList();
		a12.add("array12-name1");
		a12.add("array12-name2");
		
		a1.addAll(a12);
		
		System.out.println("after invoking addAll..." + a1);
		ArrayList<String> a13 = new ArrayList();
		a13.add("array13-name1");
		a13.add("array13-name2");
		
		a1.addAll(1,a13);
		System.out.println("after invoking addAll-1-a13..." + a1);
		
	}

}
