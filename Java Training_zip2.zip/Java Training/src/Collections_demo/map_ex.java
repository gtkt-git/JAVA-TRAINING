package Collections_demo;

import java.util.*;


public class map_ex {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> Stu = new HashMap<Integer,String>();
		Stu.put(1011, "name1");
		Stu.put(1022, "name2");
		Stu.put(1033, "name3");
		Stu.put(1044, "name4");
		
		for(Map.Entry m:Stu.entrySet())
		{	System.out.println(m.getKey()+" "+ m.getValue());	}
	}
	}

