package Collections_demo;

import java.util.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class vector_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Vector emp =new Vector();
		emp.add("1011");
		emp.add(3500);
		emp.add(6.18);
		emp.add(6.18);
		emp.add("1011");
		
		System.out.println(emp);
		
		
		Iterator i = emp.iterator();
		while (i.hasNext())
		{	System.out.println(i.next());
		
		}
	}
		
	}


