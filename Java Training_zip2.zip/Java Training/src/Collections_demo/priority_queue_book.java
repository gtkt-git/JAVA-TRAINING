package Collections_demo;

import java.util.*;

class Book5
{	String id,nos;
	String name,author,publisher;
	
	public Book5(String id,String name,String author,String publisher,String nos)
	{	this.id=id;
		this.name=name;
		this.author=author;
		this.publisher=publisher;
		this.nos=nos;
			
	}

}


public class priority_queue_book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book5 b1=new Book5("111","name1","author1","publisher1","112");
		Book5 b2=new Book5("222","name2","author2","publisher2","223");
		Book5 b3=new Book5("325","name3","author3","publisher3","325");
		Book5 b4=new Book5("441","name4","author4","publisher4","441");
		
		PriorityQueue<Book5> bookq =new PriorityQueue<Book5>();
		
//		PriorityQueue<String> q = new PriorityQueue<String>();
        bookq.add(b1);
        bookq.add(b2);
        bookq.add(b3);
        bookq.add(b4);
        
//        q.add("Ajay");
//        q.add("Anuj");
//        q.add("name5");
        
        System.out.println("Head of Queue:"+bookq.element());
        System.out.println("Head of Queue:"+bookq.peek());
        System.out.println("Queue iteration :");
        
        Iterator i = bookq.iterator();
		while (i.hasNext())
		{	
			System.out.println(i.next());
			

		}
//        hs.add(null);
		System.out.println("===========");
		bookq.poll();
		bookq.remove();
		
        Iterator j = bookq.iterator();
		while (j.hasNext())
		{	
			System.out.println(j.next());
			

		}
	
	}

}
