package Collections_demo;

import java.util.*;


public class array_list {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String> product = new ArrayList();
//		ArrayList product = new ArrayList();
		
		product.add("item2");
		product.add("item1");
		product.add("item3");
		
		for (String i:product)
		{	System.out.println(i);		}
		
		Collections.sort(product);
		System.out.println("after sorting...");
		
		for (String i:product)
		{	System.out.println(i);		}
		
	}
}
