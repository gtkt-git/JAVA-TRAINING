package Collections_demo;

import java.util.*;
//import java.util.Map;

public class map_descend {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Map<Integer,String> Stu = new HashMap<Integer,String>();
		Map<Integer,String> Stu = new LinkedHashMap<Integer,String>();
		Stu.put(1011, "name1");
		Stu.put(1022, "name2");
		Stu.put(1033, "name3");
		Stu.put(1044, "name4");
		
		Stu.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).forEach(System.out::println);
		System.out.println("sorting based on values");
		Stu.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
		
		Stu.remove(1011);
		System.out.println("after removing");
		Stu.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
		
		Stu.replace(1033, "name3","newname3");
		System.out.println("after replace name3");
		Stu.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
		
		Stu.replaceAll((k,v)->"NEWNAME");
		System.out.println("after replace all");
		Stu.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
	
		
	}

}
