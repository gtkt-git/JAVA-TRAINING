package Collections_demo;
import java.util.*;

public class tree_set {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		TreeSet<String> hs = new TreeSet<String>();
        hs.add("Ravi");
        hs.add("Ravi");
        hs.add("Ajay");
        hs.add("Anuj");
//        hs.add(null);
    
		
        System.out.println("Initial Set:"+hs);
		
        hs.remove("Ravi");
        System.out.println("after remove ravi:"+hs);
        TreeSet<String> hs2 =new TreeSet<String>();
        hs2.add("sonoo");
        hs2.add("Hanumat");
        
        hs.addAll(hs2);
        System.out.println("Updated Set:"+hs);
        hs.removeAll(hs2);
        System.out.println("After RemoveAll:"+hs);
  
        hs.clear();
        System.out.println("After invoking clear():"+hs);
                
	}

}
