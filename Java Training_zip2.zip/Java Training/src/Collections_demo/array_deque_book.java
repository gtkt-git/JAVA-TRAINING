package Collections_demo;
import java.util.*;

class Book4
{	int id,nos;
	String name,author,publisher;

	public Book4(int id,String name,String author,String publisher,int nos)
	{	this.id=id;
		this.name=name;
		this.author=author;
		this.publisher=publisher;
		this.nos=nos;
			
	}

}

public class array_deque_book {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Book4 b1=new Book4(111,"name1","author1","publisher1",112);
		Book4 b2=new Book4(222,"name2","author2","publisher2",223);
		Book4 b3=new Book4(222,"name2","author2","publisher2",223);
		Book4 b4=new Book4(441,"name4","author4","publisher4",441);
		
		Deque<Book4> emp_id=new ArrayDeque<Book4>();
		
		emp_id.add(b1);
		emp_id.add(b2);
		emp_id.offer(b3);
		emp_id.offerFirst(b4);
//		emp_id.offerFirst(10001);
		
		for(Book4 i:emp_id)
		{	System.out.println("ID:"+ i.id +" NAME: "+i.name + " AUTHOR: " + i.author + " PUBLISHER: " 
				+ i.publisher + " QTY: " + i.nos); 	}
		
		emp_id.poll();
        System.out.println("after remove 1st element");

        for(Book4 i:emp_id)
        {
        	System.out.println("ID:"+ i.id +" NAME: "+i.name + " AUTHOR: " + i.author + " PUBLISHER: " 
    				+ i.publisher + " QTY: " + i.nos);
        }

        
        emp_id.pollLast();
        System.out.println("after remove last element");
        
        for(Book4 i:emp_id)
        {
        	System.out.println("ID:"+ i.id +" NAME: "+i.name + " AUTHOR: " + i.author + " PUBLISHER: " 
    				+ i.publisher + " QTY: " + i.nos);
        }
        
	}

}
