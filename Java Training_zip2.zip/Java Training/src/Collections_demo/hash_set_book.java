package Collections_demo;
import java.util.*;

class Book2
{	int id,nos;
	String name,author,publisher;
	
	public Book2(int id,String name,String author,String publisher,int nos)
	{	this.id=id;
		this.name=name;
		this.author=author;
		this.publisher=publisher;
		this.nos=nos;
			
	}

}

public class hash_set_book {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Book2> hs = new HashSet<Book2>();
		
		Book2 b1=new Book2(111,"name1","author1","publisher1",112);
		Book2 b2=new Book2(222,"name2","author2","publisher2",223);
		Book2 b3=new Book2(222,"name2","author2","publisher2",223);
		Book2 b4=new Book2(441,"name4","author4","publisher4",441);
        hs.add(b1);
        hs.add(b2);
        hs.add(b3);
        hs.add(b4);
		
//        System.out.println("Initial Set:"+hs);
        
		for (Book2 b:hs)	// for data-type var-name collection-name
		{	 
		System.out.println("ID:"+ b.id +" NAME: "+b.name + " AUTHOR: " + b.author + " PUBLISHER: " + b.publisher + " QTY: " + b.nos);
		}
	
        
       
        hs.remove(b2);
        System.out.println("after remove b2:"+hs);
/*        
        HashSet<String> hs2 =new HashSet<String>();
        hs2.add("sonoo");
        hs2.add("Hanumat");
        
        hs.addAll(hs2);
        System.out.println("Updated Set:"+hs);
        hs.removeAll(hs2);
        System.out.println("After RemoveAll:"+hs);
  
        hs.clear();
        System.out.println("After invoking clear():"+hs);
*/                
	}

}
