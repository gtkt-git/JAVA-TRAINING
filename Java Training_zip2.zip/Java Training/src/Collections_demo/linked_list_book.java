package Collections_demo;

import java.util.*;

class Book
{	int id,nos;
	String name,author,publisher;
	
	public Book(int id,String name,String author,String publisher,int nos)
	{	this.id=id;
		this.name=name;
		this.author=author;
		this.publisher=publisher;
		this.nos=nos;
			
	}

}

public class linked_list_book {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Book> list=new LinkedList<Book>();
		
		Book b1=new Book(111,"name1","author1","publisher1",112);
		Book b2=new Book(222,"name2","author2","publisher2",223);
		
		list.add(b1);
		list.add(b2);
		
		for (Book b:list)	// for data-type var-name collection-name
		{	 
		System.out.println("ID:"+ b.id +" NAME: "+b.name + " AUTHOR: " + b.author + " PUBLISHER: " + b.publisher + " QTY: " + b.nos);
		}
		
	}

}
