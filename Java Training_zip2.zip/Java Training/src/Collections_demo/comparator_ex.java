package Collections_demo;
import java.util.*;
import java.io.*;

class Stu9 implements Comparable<Stu9>
{	int regno,age;
	String name;
	
	Stu9(int regno, int age,String name)
	{	this.regno=regno;
		this.age=age;
		this.name=name;
	}
	
	public int compareTo(Stu9 s)
	{	if (age==s.age)
		{	return 0;	}
		else if (age>s.age)
		{	return 1;	}
		else	{	return -1;	}
	}
}

class ageCompare implements Comparator<Stu9>
{	public int compare(Stu9 c1, Stu9 c2)
	{		if (c1.age==c2.age)
	{	return 0;	}
	else if (c1.age>c2.age)
	{	return 1;	}
	else	{	return -1;	}
}
}

class nameCompare implements Comparator<Stu9>
{	public int compare(Stu9 c1, Stu9 c2)
	{		return c1.name.compareTo(c2.name);
}
}




public class comparator_ex {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


		ArrayList<Stu9> a1=new ArrayList<Stu9>();
		a1.add(new Stu9(11,20,"name1"));
		a1.add(new Stu9(12,21,"name2"));
		a1.add(new Stu9(13,19,"name3"));
		System.out.println("sorting by name");
		Collections.sort(a1, new nameCompare());
		for (Stu9 st:a1)
		{	System.out.println(st.regno+" "+st.age+" "+st.name); }
		
			
		System.out.println("sorting by age");
		Collections.sort(a1, new ageCompare());
		for (Stu9 st:a1)
		{	System.out.println(st.regno+" "+st.age+" "+st.name); }
		
	}

}
