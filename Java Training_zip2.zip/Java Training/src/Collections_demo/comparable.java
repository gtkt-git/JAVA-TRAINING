package Collections_demo;
import java.util.*;
import java.io.*;

class Stu8 implements Comparable<Stu8>
{	int regno,age;
	String name;
	
	Stu8(int regno, int age,String name)
	{	this.regno=regno;
		this.age=age;
		this.name=name;
	}
	
//	public int compareTo(Stu8 s)			// COMPARING AGE TO SORT LATER. MUST USE compareTo
//	{	if (age==s.age)						// because Comparable uses it to do comparison & sorting. 
//		{	return 0;	}				// compareTo is a method in Comparable.
//		else if (age>s.age)
//		{	return 1;	}
//		else	{	return -1;	}
//	}
	
	public int compareTo(Stu8 s)		//	COMPARING REGNO TO SORT LATER
	{	if (regno==s.regno)
		{	return 0;	}
		else if (regno>s.regno)
		{	return 1;	}
		else	{	return -1;	}
	}
}

public class comparable {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Stu8> a1=new ArrayList<Stu8>();
		a1.add(new Stu8(11,20,"name1"));
		a1.add(new Stu8(12,21,"name2"));
		a1.add(new Stu8(13,19,"name3"));
		
		Collections.sort(a1);
		for (Stu8 st:a1)
		{	System.out.println("regno: "+st.regno+" "+"age: "+st.age+" "+"name: "+ st.name); }
		
	}

}
